<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('LoginModal');
		$this->load->helper('securepostdata_helper');
		if($this->session->userdata('usersessiondetails')) {
			redirect('HomeController/index');
		}
	}

	public function index()
	{
		// $this->input->post();   =======    equals $_POST[]
		$submit = $this->input->post('submit');
		if(!empty($submit)){
			unset($_POST['submit']);
			$data = getPostData($this->input->post()); // calling helper's method
			$result = $this->LoginModal->checkLogin($data);
			// setting session  $this->session->set_userdata($array);
			if($result['success'] == 'true'){
				$arr = array('email'=>$result['data']['email']);
				$this->session->set_userdata('usersessiondetails',$arr); // usersessiondetails is session name
				redirect('HomeController/index');
			}else{
				$msg = $result['data'];
				echo '<script>alert("$msg")</script>';
			} 
		}
		$this->load->view('login');
	}





}

/* End of file LoginController.php */
/* Location: ./application/controllers/LoginController.php */

 ?>