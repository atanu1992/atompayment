<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AtomController extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		// include_once APPPATH.'third_party/atompay/sample.php';
	}

	public function index()
	{
		include_once APPPATH.'third_party/atompay/sample.php';
	}

	public function response($value='')
	{
		include_once APPPATH.'third_party/atompay/response.php';
	}

}

/* End of file AtomController.php */
/* Location: ./application/controllers/AtomController.php */